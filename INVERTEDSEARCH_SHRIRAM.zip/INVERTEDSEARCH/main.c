/******************************************INVERTED SEARCH****************************************************
******************************************NAME:SHRIRAM PAI************************************************************888
******************************************USER ID:25005_168*********************************************************************************************/

#include "inverted_index.h"
#include<string.h>
mainNode *hashtable[26]={NULL};
int read_and_validate(int argc,char *argv[])
{
    if(argc<3)
    {
        printf("Usage %s<filename>\n",argv[0]);
        return FAILURE;
    }
    for(int i=1;i<argc;i++)
    {
        if(strstr(argv[i],".txt")==NULL)
        {
            printf("File %s does not have .txt extension\n",argv[i]);
            return FAILURE;
        }
        FILE *fptr=fopen(argv[i],"r");
        if(fptr==NULL)
        {
            printf("Failed to open the file %s\n",argv[i]);
            return FAILURE;
        }
        //check if file is empty
        fseek(fptr,0,SEEK_END);
        if(ftell(fptr)==0)
        {
         printf("%s file does not have any data\n",argv[i]);
         fclose(fptr);
         continue;
        }
        rewind(fptr);
        //check for duplicate file 
        for(int j=1;j<i;j++)
        {
            if(strcmp(argv[i],argv[j])==0)
            {
                printf("%s duplicate file found\n",argv[i]);
                fclose(fptr);
                continue;
            }
            
        }
        fclose(fptr);
    }
    return SUCCESS;
}
Slist *create_filelist(int argc, char *argv[]) {
    Slist *head = NULL;
    Slist *tail = NULL;
    for(int i = 1; i < argc; i++) {
        Slist *new_node = malloc(sizeof(Slist));
        strcpy(new_node->filename, argv[i]);
        new_node->link = NULL;
        if(head == NULL) {
            head = new_node;
            tail = new_node;
        } else {
            tail->link = new_node;
            tail = new_node;
        }
    }
    return head;
}

int main(int argc,char *argv[])
{
  if(read_and_validate(argc,argv)==FAILURE)
    return FAILURE;
 printf("Read and validate successfull\n");
  //Slist *head=NULL;
  Slist *head = create_filelist(argc, argv);
   char choice;
   while(1)
   {
   printf("\n1.create database\n2.Display Database\n3.search database\n4.save database\n5.update database\n");
   printf("Enter the choice\n");
   scanf(" %c",&choice);
   getchar();
   switch(choice)
   {
        case '1':
            int result=create_database(&head,hashtable);
             if(result==FAILURE)
             {
                printf("Create database failed\n");
             }
             else{
             printf("Create database successfull\n");
             }
        break;

        case '2':
        display_database(hashtable);
        printf("\nDisplay database successfull");
        break;

        case '3':
        search_database(hashtable);
        printf("Search database succesfull\n");
        break;

        case '4':
        save_database(hashtable);
        printf("Save database successfull\n");
        break;

        case '5':
        update_database(hashtable);
        printf("Update database successfull\n");
        break;
   }
}
}