 #include "inverted_index.h"
int display_database(mainNode *hashtable[])
{
    for(int i=0;i<26;i++)
    {
        if(hashtable[i]!=NULL)
        {
            mainNode *wptr=hashtable[i];
          //  printf("%d has entries\n",i);
            while(wptr!=NULL)
            {
                printf("\n");
                printf("\n #%d ;",i);
                printf("\t%s ;\t%d ;",wptr->word,wptr->file_count);

                subNode *fptr=wptr->file_list;
                while(fptr!=NULL)
                {
                    printf("\t%s;\t%d;",fptr->filename,fptr->word_count);
                    fptr=fptr->link;
                }
                wptr=wptr->link;
            }
        }
    }
    return SUCCESS;
}
