#include "inverted_index.h"
int  search_database(mainNode *hashtable[]) 
{
    char word[100];
    printf("Enter the word\n");
    scanf("%s",word);
    int index;
    if(isupper(word[0]))
    {
      index=word[0]%65;
    }
    else if(islower(word[0]))
    {
      index=word[0]%97;
    }
    else{
      index=26;
    }
    mainNode *wptr=hashtable[index];
    while(wptr!=NULL)
    {
       if(strcmp(wptr->word,word)==0)
       {
         printf("%s word found found at index %d\n",word,index);
         return index;
       }
       wptr=wptr->link;
       
    }
    printf("Word not found\n");
    return FAILURE;
}