#include "inverted_index.h"
void save_database(mainNode *hashtable[])
{
char filename[100];
printf("Enter the backup filename\n");
scanf("%s",filename);
FILE *fp=fopen(filename,"w");
if(fp ==NULL)
{
    printf("Failed to open %s file\n",filename);
}
for(int i=0;i<26;i++)
{
    if(hashtable[i]!=NULL)
    {
        mainNode *wptr=hashtable[i];
        while(wptr!=NULL)
        {
            fprintf(fp,"%s %d\n",wptr->word,wptr->file_count);
            subNode *fptr=wptr->file_list;
            while(fptr!=NULL)
            {
             
              fprintf(fp,"%s %d\n",fptr->filename,fptr->word_count);
              fptr=fptr->link;  
            }
            wptr=wptr->link;
        }
    }
}
fclose(fp);
printf("Backup file is updated\n");
}