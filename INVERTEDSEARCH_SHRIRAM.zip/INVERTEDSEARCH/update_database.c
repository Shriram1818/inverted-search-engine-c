#include "inverted_index.h"
int update_database(mainNode *hashtable[])
{
    char filename[100];
    int is_empty = 1;

    // Check if database is empty
    for (int i = 0; i < 25; i++)
    {
        if (hashtable[i] != NULL)
        {
            is_empty = 0;
            break;
        }
    }

    if (!is_empty)
    {
        printf("Database is not empty. Updating...\n");
    }

    printf("Enter the backup filename: ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Failed to open file %s\n", filename);
        return FAILURE;
    }

    if (strstr(filename, ".txt"))
    {
        printf("File has .txt extension\n");
    }

    char word[100];
    int file_count;

    // Read mainNode data from file
    while (fscanf(fp, "%s %d", word, &file_count) == 2)
    {
        int index;
        if(isupper(word[0]))
        {
            index=word[0] %65;
        }
        else if(islower(word[0]))
        {
            index=word[0]%97;
        }
        else{
            index=26;
        }

        mainNode *main = malloc(sizeof(mainNode));
        strcpy(main->word, word);
        main->file_count = file_count;
        main->file_list = NULL;
        main->link = NULL;

        // Read subNode data for this word
        for (int i = 0; i < file_count; i++)
        {
            char sub_filename[100];
            int word_count;

            if (fscanf(fp, "%s %d", sub_filename, &word_count) != 2)
                break;

            subNode *new_sub = malloc(sizeof(subNode));
            strcpy(new_sub->filename, sub_filename);
            new_sub->word_count = word_count;
            new_sub->link = NULL;

            if (main->file_list == NULL)
            {
                main->file_list = new_sub;
            }
            else
            {
                subNode *temp = main->file_list;
                while (temp->link != NULL)
                    temp = temp->link;
                temp->link = new_sub;
            }
        }

        // Insert mainNode into hashtable
        if (hashtable[index] == NULL)
        {
            hashtable[index] = main;
        }
        else
        {
            mainNode *temp = hashtable[index];
            while (temp->link != NULL)
                temp = temp->link;
            temp->link = main;
        }
    }

    fclose(fp);
    printf("Database updated successfully from %s\n", filename);
    return SUCCESS;
}
