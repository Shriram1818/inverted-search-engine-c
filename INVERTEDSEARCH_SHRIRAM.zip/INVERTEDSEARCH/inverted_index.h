#ifndef INVERTED_INDEX_H
#define INVERTED_INDEX_H
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
typedef struct Slist
{
    char filename[100];
    struct Slist *link;
}Slist;
typedef struct subNode
{
   char filename[100];
   int word_count;
   struct subNode *link;     //links to the files when same word exists with the different files
}subNode;
typedef struct mainNode
{
    char word[100];  
    int file_count;
    struct mainNode *link;   //links to the mainnode with the same index
    subNode *file_list;  //links the mainnode and subnode
}mainNode;
extern mainNode *hashtable[26];
int create_database(Slist **head,mainNode *hastable[]);
int display_database(mainNode *hastable[]);
int update_database(mainNode *hastable[]);
int  search_database(mainNode *hashtable[]); 
void save_database(mainNode *hashtable[]);
#define FAILURE 0
#define SUCCESS 1
#endif