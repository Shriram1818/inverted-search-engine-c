#include "inverted_index.h"
int create_database(Slist **head,mainNode *hashtable[])
{
  int index;
  for(int i=0;i<26;i++)   //initialize each index of hashtable with the NULL
{
  hashtable[i]=NULL;
}
   Slist *temp=*head;    //initialize temp with the first filename it iterates over each filename
   while(temp !=NULL)
   {
     printf("%s Opening file\n",temp->filename);  
   
   FILE *fptr=fopen(temp->filename,"r");  //opens file in read mode
   if(!fptr)
   {
    printf("could not open file %s\n",temp->filename);
    temp=temp->link;
    continue;
   }
    printf("File %s is opened\n",temp->filename);
    char word[100];
    while(fscanf(fptr,"%s",word)!=EOF)   //reads one word at a time from file word by word using fscanf
    {
      printf("Word %s is readed from %s file\n",word,temp->filename); 
      if(isupper(word[0]))     //calculates the index so that in which index it is to be inserted
      {
        index=word[0]%65;  
      }
      else if(islower(word[0]))  
      {
        index=word[0]%97;
      }
      else
      {
       index=26;
      }
      mainNode *wptr=hashtable[index];     //if the mainnode is not null and there is already present int it
      mainNode *prev_word=NULL;
      while(wptr!=NULL && strcmp(wptr->word,word)!=0)
      {
        prev_word=wptr;
        wptr=wptr->link;
      }
      if(wptr==NULL)
      {
      mainNode *new_word=malloc(sizeof(mainNode));   //if the hastable is empty create new mainnode 
      strcpy(new_word->word,word);
      new_word->file_count=1;
      new_word->link=NULL;
      new_word->file_list=NULL;
      subNode *new_file=malloc(sizeof(subNode));
      strcpy(new_file->filename,temp->filename);
      new_file->word_count=1;
      new_file->link=NULL;

      new_word->file_list=new_file;
      if(prev_word==NULL)
      {
        hashtable[index]=new_word;

      }
      else{
      prev_word->link=new_word;
      printf("Inserted %s word and %d times\n",word,new_word->file_count);
      }
    }
      else
      {
        subNode *fptr2=wptr->file_list;    
        subNode *prev_file=NULL;
        while(fptr2!=NULL && strcmp(fptr2->filename,temp->filename)!=0)
        {
          prev_file=fptr2;
         fptr2=fptr2->link;
        }
        if(fptr2!=NULL)
        {
          fptr2->word_count++;
        }
        else
        {
          subNode *new_file=malloc(sizeof(subNode));  //if there is no subnode create new subnode
          strcpy(new_file->filename,temp->filename);
          new_file->word_count=1;
          new_file->link=NULL;
          if(wptr->file_list ==NULL)
          {
            wptr->file_list=new_file;

          }
          else if(prev_file==NULL)
          {
            new_file->link=wptr->file_list;
            wptr->file_list=new_file;
          }
          else{
            prev_file->link=new_file;
          }
          wptr->file_count++;
          printf("Added new filename %s for %s word\n",temp->filename,word);
        }
      }
      
    }
    temp=temp->link;
    }

  return SUCCESS;
    
}
